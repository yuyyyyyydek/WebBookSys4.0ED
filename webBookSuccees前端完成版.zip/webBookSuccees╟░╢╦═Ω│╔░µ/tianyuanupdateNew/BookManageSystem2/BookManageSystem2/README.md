# 图书管理系统前端(Lin版)
index.html为登陆页面
Home.html为用户登陆后的界面
ReaderAdd.html为读者注册的页面
ReaderHome.html为读者登陆后的界面